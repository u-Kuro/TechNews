<?php
  $hostname= "technews";
  $conn=mysqli_connect("localhost","root","","technews") or die("connection failed ". mysqli_connect_error());
?>
